"""
Step 1 - Generate a SIMULATED retail dataset (no real company data).

Why simulate? Real retail inventory data is confidential. This script builds a realistic
12-month dataset (Oct-2025 -> Sep-2026) for 5 stores x 120 products, using a day-by-day
inventory simulation (demand -> sales -> stock -> reorder -> supplier lead time).

Some products are deliberately given weak reorder policies so the analysis has real
shortage / overstock patterns to discover:
  * "lean"     policy  -> orders too little, too late  -> stockouts (mostly high-demand items)
  * "heavy"    policy  -> orders far too much          -> overstock (mostly slow-moving items)
  * "balanced" policy  -> reasonable
The analysis code never reads the policy column - it has to discover the problem from data.
"""
import numpy as np, pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)

START, END = pd.Timestamp("2025-10-01"), pd.Timestamp("2026-09-30")
DAYS = pd.date_range(START, END, freq="D")

# ---------------------------------------------------------------- stores
stores = pd.DataFrame({
    "store_id": [1, 2, 3, 4, 5],
    "store_name": ["Bengaluru - Indiranagar", "Bengaluru - Whitefield", "Mysuru - Vijayanagar",
                   "Mangaluru - Hampankatta", "Hubballi - Keshwapur"],
    "city": ["Bengaluru", "Bengaluru", "Mysuru", "Mangaluru", "Hubballi"],
    "region": ["South Metro", "South Metro", "South Tier-2", "Coastal", "North Karnataka"],
    "size_sqft": [4200, 5100, 3000, 2800, 3200],
})
store_factor = {1: 1.35, 2: 1.45, 3: 0.85, 4: 0.80, 5: 0.75}

# ---------------------------------------------------------------- products
cats = {  # category: (n_products, cost range, margin range, base daily demand range per store, lead-time range)
    "Grocery Staples":     (20, (30, 220),   (0.10, 0.22), (1.5, 9.0),  (2, 5)),
    "Beverages":           (16, (15, 140),   (0.18, 0.35), (1.5, 8.0),  (2, 6)),
    "Snacks":              (16, (8, 90),     (0.20, 0.38), (1.5, 8.0),  (2, 6)),
    "Personal Care":       (16, (40, 380),   (0.25, 0.45), (0.5, 4.0),  (4, 9)),
    "Household":           (16, (35, 450),   (0.20, 0.40), (0.4, 3.5),  (4, 9)),
    "Electronics Acc.":    (12, (150, 2200), (0.30, 0.55), (0.1, 1.2),  (7, 14)),
    "Apparel":             (12, (180, 1400), (0.40, 0.60), (0.15, 1.5), (7, 16)),
    "Stationery":          (12, (10, 160),   (0.25, 0.50), (0.2, 2.0),  (3, 8)),
}
rows, pid = [], 1
for cat, (n, cost_r, mar_r, dem_r, lt_r) in cats.items():
    for i in range(n):
        cost = round(float(np.exp(rng.uniform(np.log(cost_r[0]), np.log(cost_r[1])))), 2)
        price = round(cost * (1 + rng.uniform(*mar_r)), 2)
        base = float(np.exp(rng.uniform(np.log(dem_r[0]), np.log(dem_r[1]))))
        rows.append(dict(product_id=pid, sku=f"SKU{pid:04d}", product_name=f"{cat} Item {i+1:02d}",
                         category=cat, supplier_id=int(rng.integers(1, 9)),
                         unit_cost=cost, unit_price=price,
                         lead_time_days=int(rng.integers(lt_r[0], lt_r[1] + 1)), _base=base))
        pid += 1
products = pd.DataFrame(rows)

# hidden reorder-policy assignment (drives the planted problems)
q_hi, q_lo = products["_base"].quantile(0.75), products["_base"].quantile(0.35)
def policy(b):
    r = rng.random()
    if b >= q_hi:  return "lean" if r < 0.35 else "balanced"
    if b <= q_lo:  return "heavy" if r < 0.55 else "balanced"
    return "heavy" if r < 0.12 else ("lean" if r < 0.20 else "balanced")
products["_policy"] = products["_base"].apply(policy)

# category seasonality by month (1..12)
def season(cat, m):
    if cat == "Beverages":      return {3:1.15,4:1.3,5:1.4,6:1.2,7:0.95,8:0.9,12:0.9,1:0.85}.get(m, 1.0)
    if cat == "Apparel":        return {10:1.35,11:1.5,12:1.25,1:0.9,2:0.85,6:0.9}.get(m, 1.0)
    if cat == "Electronics Acc.": return {10:1.3,11:1.35,12:1.1}.get(m, 1.0)
    if cat == "Stationery":     return {6:1.5,7:1.4,4:1.1}.get(m, 0.95)
    if cat == "Snacks":         return {10:1.2,11:1.2,12:1.15}.get(m, 1.0)
    return 1.0
dow = np.array([0.9, 0.9, 0.9, 0.95, 1.05, 1.3, 1.35])  # Mon..Sun

# ---------------------------------------------------------------- simulation
sales_rows, snap_rows, cur_rows = [], [], []
month_ends = set(pd.date_range(START, END, freq="ME"))
sale_id = 1
for _, p in products.iterrows():
    cat, lt, pol = p["category"], int(p["lead_time_days"]), p["_policy"]
    for s in stores["store_id"]:
        base = p["_base"] * store_factor[s] * rng.uniform(0.85, 1.15)
        # policy parameters (in days of demand)
        if pol == "balanced": rop_d, order_d, init_d = lt + 5, 22, 25
        elif pol == "lean":   rop_d, order_d, init_d = max(lt - 1, 1), 6, 8
        else:                 rop_d, order_d, init_d = 38 + lt, 85, 110
        rop = max(int(round(base * rop_d)), 1)
        q_order = max(int(round(base * order_d)), 4)
        stock = int(round(base * init_d))
        pipeline = []                      # list of (arrival_day_index, qty)
        m_recv = m_sold = m_lostu = m_sod = 0
        lam_hist = []
        for di, day in enumerate(DAYS):
            # receipts
            arr = sum(q for a, q in pipeline if a == di)
            if arr: stock += arr; m_recv += arr
            pipeline = [(a, q) for a, q in pipeline if a > di]
            lam = base * season(cat, day.month) * dow[day.dayofweek]
            demand = int(rng.poisson(lam))
            sold = min(demand, stock)
            lost = demand - sold
            stock -= sold
            m_sold += sold; m_lostu += lost
            if demand > 0 and stock == 0 and lost > 0: m_sod += 1
            elif stock == 0 and demand == 0: pass
            if sold > 0:
                disc = float(rng.choice([0, 0, 0, 0, 0.05, 0.10, 0.20], p=[.5,.1,.1,.05,.1,.1,.05]))
                sales_rows.append((sale_id, day.date().isoformat(), int(s), int(p["product_id"]), sold,
                                   p["unit_price"], disc)); sale_id += 1
            # reorder check (inventory position = on hand + on order)
            position = stock + sum(q for _, q in pipeline)
            if position <= rop:
                delay = lt + int(rng.integers(0, 3))
                pipeline.append((di + delay, q_order))
            if day in month_ends:
                snap_rows.append((day.date().isoformat(), int(s), int(p["product_id"]), stock,
                                  m_recv, m_sold, m_sod, m_lostu))
                m_recv = m_sold = m_lostu = m_sod = 0
        cur_rows.append((int(s), int(p["product_id"]), stock, rop, q_order,
                         sum(q for _, q in pipeline)))

sales = pd.DataFrame(sales_rows, columns=["sale_id","sale_date","store_id","product_id","quantity","unit_price","discount_pct"])
snap = pd.DataFrame(snap_rows, columns=["snapshot_date","store_id","product_id","units_on_hand","units_received","units_sold","stockout_days","lost_units"])
cur = pd.DataFrame(cur_rows, columns=["store_id","product_id","units_on_hand","reorder_level","reorder_qty","units_on_order"])

suppliers = pd.DataFrame({"supplier_id": range(1, 9),
    "supplier_name": [f"Supplier {c}" for c in "ABCDEFGH"]})

# write (hidden columns are NOT exported)
products.drop(columns=["_base", "_policy"]).to_csv(OUT/"products.csv", index=False)
stores.to_csv(OUT/"stores.csv", index=False)
suppliers.to_csv(OUT/"suppliers.csv", index=False)
sales.to_csv(OUT/"sales.csv", index=False)
snap.to_csv(OUT/"inventory_snapshot.csv", index=False)
cur.to_csv(OUT/"inventory_current.csv", index=False)
# answer key kept OUTSIDE the analysis path, only used to sanity-check the analysis
products[["product_id", "_policy"]].rename(columns={"_policy": "planted_policy"}).to_csv(OUT.parent/"_answer_key.csv", index=False)

print(f"products={len(products)} stores={len(stores)} sales rows={len(sales):,} snapshots={len(snap):,} current={len(cur)}")
print("revenue (Rs):", f"{(sales.quantity*sales.unit_price*(1-sales.discount_pct)).sum():,.0f}")
