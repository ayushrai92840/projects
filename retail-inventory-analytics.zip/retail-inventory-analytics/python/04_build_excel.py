"""Step 4 - Excel workbook: query outputs as data sheets + a Summary sheet driven by live formulas."""
import pandas as pd
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.comments import Comment

ROOT = Path(__file__).resolve().parents[1]; T = ROOT/"outputs/tables"
rd = lambda n: pd.read_csv(T/f"{n}.csv")
F = "Arial"
f_norm, f_bold = Font(name=F, size=10), Font(name=F, size=10, bold=True)
f_head = Font(name=F, size=10, bold=True, color="FFFFFF"); fill_head = PatternFill("solid", fgColor="1F3A5F")
f_input = Font(name=F, size=10, color="0000FF"); fill_input = PatternFill("solid", fgColor="FFF2CC")
f_title = Font(name=F, size=16, bold=True, color="1F3A5F"); f_note = Font(name=F, size=9, italic=True, color="595959")
thin = Side(style="thin", color="D9D9D9")

wb = Workbook()
def write_df(ws, df, widths=None, money=(), pct=(), dec=()):
    for j, c in enumerate(df.columns, 1):
        cell = ws.cell(1, j, c); cell.font, cell.fill = f_head, fill_head
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for i, row in enumerate(df.itertuples(index=False), 2):
        for j, v in enumerate(row, 1):
            c = ws.cell(i, j, None if pd.isna(v) else (v.item() if hasattr(v, "item") else v)); c.font = f_norm
            name = df.columns[j-1]
            if name in money: c.number_format = '#,##0'
            elif name in pct: c.number_format = '0.0'
            elif name in dec: c.number_format = '0.00'
    ws.row_dimensions[1].height = 32; ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{L(len(df.columns))}{len(df)+1}"
    for j, c in enumerate(df.columns, 1):
        w = max(len(str(c)) * 0.9, df[c].astype(str).str.len().max() * 1.05 if len(df) else 8)
        ws.column_dimensions[L(j)].width = min(max(w + 2, 11), 34)

# ---------- Assumptions
wa = wb.active; wa.title = "Assumptions"
wa["A1"] = "Assumptions & definitions"; wa["A1"].font = f_title
rows = [("Annual holding cost rate", 0.20, "Share of stock value it costs per year to hold inventory (capital, storage, shrink). ASSUMPTION - edit to see Summary update."),
        ("Overstock threshold (days of cover)", 90, "Used in SQL (sql/03_inventory_health.sql): > 90 days of cover = Overstock"),
        ("Excess = stock above (days of cover)", 60, "Used in SQL: units above 60 days of demand are 'excess'"),
        ("Demand window (days)", 90, "Average daily demand = last 90 days of sales"),
        ("Shortage rule", "cover < lead time", "Stock will run out before a new order could arrive; Stockout = 0 units on hand")]
for i, (a, b, c) in enumerate(rows, 3):
    wa.cell(i, 1, a).font = f_bold; cb = wa.cell(i, 2, b); wa.cell(i, 3, c).font = f_note
    cb.font = f_input if i == 3 else f_norm
    if i == 3: cb.fill = fill_input; cb.number_format = "0%"
wa["A10"] = "Blue text on yellow = input you can change. Everything on 'Summary' is a formula over the data sheets. Data is SIMULATED (see README)."; wa["A10"].font = f_note
wa.column_dimensions["A"].width = 38; wa.column_dimensions["B"].width = 20; wa.column_dimensions["C"].width = 110

# ---------- data sheets
ss = rd("stock_status_all").drop(columns=["annual_holding_cost"])
ss = ss[["store_name","sku","product_name","category","unit_cost","unit_price","lead_time_days","units_on_hand","units_on_order","reorder_level",
         "avg_daily_units","days_of_cover","stock_status","suggested_order_qty","excess_units","excess_value"]]
ss["avg_daily_units"] = ss.avg_daily_units.round(2)
ws_ss = wb.create_sheet("Stock_Status"); write_df(ws_ss, ss, money=("units_on_hand","excess_value","suggested_order_qty","excess_units"), dec=("avg_daily_units","unit_cost","unit_price"), pct=("days_of_cover",))
n_ss = len(ss) + 1
hc = len(ss.columns) + 1; ws_ss.cell(1, hc, "annual_holding_cost").font = f_head; ws_ss.cell(1, hc).fill = fill_head
ws_ss.cell(1, hc).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
ws_ss.cell(1, hc).comment = Comment("= excess_value x holding cost rate on 'Assumptions'!B3", "Analyst")
for r in range(2, n_ss + 1):
    c = ws_ss.cell(r, hc, f"=P{r}*Assumptions!$B$3"); c.font = f_norm; c.number_format = "#,##0"
ws_ss.column_dimensions[L(hc)].width = 16; ws_ss.auto_filter.ref = f"A1:{L(hc)}{n_ss}"
col = {c: L(i+1) for i, c in enumerate(ss.columns)}   # column letters by name
rng = lambda name: f"Stock_Status!${col[name]}$2:${col[name]}${n_ss}"
hc_rng = f"Stock_Status!${L(hc)}$2:${L(hc)}${n_ss}"
stat_rng = f"${col['stock_status']}$2:${col['stock_status']}${n_ss}"
for txt, color in [("Stockout","F8CBAD"),("Shortage Risk","FCE4D6"),("Overstock","DDEBF7")]:
    ws_ss.conditional_formatting.add(f"{col['stock_status']}2:{col['stock_status']}{n_ss}", CellIsRule(operator="equal", formula=[f'"{txt}"'], fill=PatternFill("solid", bgColor=color, fgColor=color)))

rl = rd("reorder_list_shortages"); wr = wb.create_sheet("Reorder_List"); write_df(wr, rl, money=("order_value",), dec=("avg_daily_units",), pct=("days_of_cover",))
ol = rd("overstock_list"); wo = wb.create_sheet("Overstock_List"); write_df(wo, ol, money=("excess_value","annual_holding_cost"), dec=("avg_daily_units",), pct=("days_of_cover",))
pp = rd("product_performance"); wp = wb.create_sheet("Product_Performance")
write_df(wp, pp, money=("units_sold","revenue","cogs","gross_profit","avg_inventory_value","lost_units","est_lost_revenue","excess_value","annual_holding_cost"), dec=("inventory_turnover","unit_cost","unit_price"), pct=("gross_margin_pct","days_inventory_outstanding","days_of_cover"))
pcol = {c: L(i+1) for i, c in enumerate(pp.columns)}; n_pp = len(pp) + 1
prng = lambda name: f"Product_Performance!${pcol[name]}$2:${pcol[name]}${n_pp}"
cat = rd("category_performance"); wc = wb.create_sheet("Category"); write_df(wc, cat, money=("revenue","gross_profit","stockout_days","est_lost_revenue","excess_inventory_value"), dec=("inventory_turnover",), pct=("gross_margin_pct","days_inventory_outstanding"))
ms = rd("monthly_sales_trend"); wm = wb.create_sheet("Monthly_Sales"); write_df(wm, ms, money=("revenue","gross_profit","units_sold"), pct=("gross_margin_pct",))
st = rd("store_performance"); wt = wb.create_sheet("Store_Performance"); write_df(wt, st, money=("revenue","excess_inventory_value"), pct=("gross_margin_pct",))

# ---------- Summary (all formulas)
s = wb.create_sheet("Summary", 0); s.sheet_view.showGridLines = False
s["A1"] = "Retail Inventory & Sales Analytics - Summary"; s["A1"].font = f_title
s["A2"] = "Oct 2025 - Sep 2026 | 5 stores | 120 SKUs | amounts in Rs (INR) | simulated data | every number below is a live formula"; s["A2"].font = f_note
def hdr(r, text):
    for c in range(1, 4): s.cell(r, c).fill = fill_head
    s.cell(r, 1, text).font = f_head
def kpi(r, label, formula, fmt, note=""):
    s.cell(r, 1, label).font = f_norm; c = s.cell(r, 2, formula); c.font = f_bold; c.number_format = fmt
    s.cell(r, 3, note).font = f_note
    for k in range(1, 4): s.cell(r, k).border = Border(bottom=thin)
hdr(4, "Sales")
kpi(5, "Total revenue", "=SUM(Monthly_Sales!B2:B13)", '#,##0', "Sum of monthly revenue (after discounts)")
kpi(6, "Gross profit", "=SUM(Monthly_Sales!C2:C13)", '#,##0')
kpi(7, "Gross margin %", "=B6/B5", '0.0%')
kpi(8, "Units sold", "=SUM(Monthly_Sales!E2:E13)", '#,##0')
hdr(10, "Inventory efficiency")
kpi(11, "Inventory turnover (x per year)", f"=SUM({prng('cogs')})/SUM({prng('avg_inventory_value')})", '0.0"x"', "COGS / average month-end inventory value")
kpi(12, "Days inventory outstanding", "=365/B11", '0.0', "365 / turnover")
kpi(13, "Current inventory value (at cost)", f"=SUMPRODUCT({rng('units_on_hand')},{rng('unit_cost')})", '#,##0')
hdr(15, "Stock health (SKU x store combinations)")
kpi(16, "Total combinations", f"=COUNTA({rng('sku')})", '#,##0')
for i, status in enumerate(["Healthy", "Shortage Risk", "Stockout", "Overstock"]):
    r = 17 + i; kpi(r, status, f'=COUNTIF({rng("stock_status")},"{status}")', '#,##0')
    s.cell(r, 3, f"=B{r}/$B$16").number_format = '0.0%"  of combinations"'; s.cell(r, 3).font = f_note
kpi(21, "Shortage or stockout combinations", "=B18+B19", '#,##0', "Need a reorder now")
hdr(23, "Money at stake")
kpi(24, "Estimated lost revenue from stockouts (12 mo)", f"=SUM({prng('est_lost_revenue')})", '#,##0', "Lost units x unit price")
kpi(25, "Excess inventory value (at cost)", f"=SUM({rng('excess_value')})", '#,##0', "Units above 60 days of cover")
kpi(26, "Excess as % of inventory", "=B25/B13", '0.0%')
kpi(27, "Annual holding cost of excess", f"=SUM({hc_rng})", '#,##0', "Excess value x holding rate (Assumptions!B3)")
kpi(28, "Suggested replenishment value (now)", f"=SUMPRODUCT({rng('suggested_order_qty')},{rng('unit_cost')})", '#,##0', "Order qty to reach lead time + 30 days cover")

# category x status table
hdr(30, "Stock status by category (combinations)")
for j, t in enumerate(["Category", "Shortage / Stockout", "Overstock"], 1): s.cell(31, j, t).font = f_bold
cats = list(cat.category)
for i, cname in enumerate(cats):
    r = 32 + i; s.cell(r, 1, cname).font = f_norm
    s.cell(r, 2, f'=COUNTIFS({rng("category")},A{r},{rng("stock_status")},"Shortage Risk")+COUNTIFS({rng("category")},A{r},{rng("stock_status")},"Stockout")').font = f_norm
    s.cell(r, 3, f'=COUNTIFS({rng("category")},A{r},{rng("stock_status")},"Overstock")').font = f_norm
s.column_dimensions["A"].width = 46; s.column_dimensions["B"].width = 18; s.column_dimensions["C"].width = 52

ch = BarChart(); ch.type = "bar"; ch.title = "Shortage vs overstock by category"; ch.style = 10; ch.height, ch.width = 9, 16
ch.add_data(Reference(s, min_col=2, max_col=3, min_row=31, max_row=31+len(cats)), titles_from_data=True)
ch.set_categories(Reference(s, min_col=1, min_row=32, max_row=31+len(cats))); ch.y_axis.delete = False; ch.x_axis.delete = False
s.add_chart(ch, "E4")
lc = LineChart(); lc.title = "Monthly revenue (Rs)"; lc.height, lc.width = 8, 16; lc.legend = None
lc.add_data(Reference(wm, min_col=2, min_row=1, max_row=13), titles_from_data=True); lc.set_categories(Reference(wm, min_col=1, min_row=2, max_row=13))
lc.y_axis.delete = False; lc.x_axis.delete = False; s.add_chart(lc, "E23")

wb.move_sheet("Assumptions", offset=len(wb.sheetnames))
out = ROOT/"outputs/Retail_Inventory_Analytics.xlsx"; wb.save(out); print("saved", out)
