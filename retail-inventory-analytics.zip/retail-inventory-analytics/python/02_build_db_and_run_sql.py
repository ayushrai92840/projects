"""Step 2 - Load the CSVs into SQLite, create the views, run every report in sql/05_reports.sql
and export each result to outputs/tables/<name>.csv (these feed Excel + Power BI)."""
import re, sqlite3, pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "retail.db"
if DB.exists(): DB.unlink()
con = sqlite3.connect(DB)

con.executescript((ROOT/"sql/01_schema.sql").read_text())
for t in ["suppliers", "stores", "products", "sales", "inventory_snapshot", "inventory_current"]:
    pd.read_csv(ROOT/f"data/raw/{t}.csv").to_sql(t, con, if_exists="append", index=False)
for f in ["02_sales_kpis.sql", "03_inventory_health.sql", "04_product_performance.sql"]:
    con.executescript((ROOT/"sql"/f).read_text())

# --- run named reports
text = (ROOT/"sql/05_reports.sql").read_text()
blocks = re.split(r"^-- name:\s*(\w+)\s*$", text, flags=re.M)[1:]
out = ROOT/"outputs/tables"; out.mkdir(parents=True, exist_ok=True)
for name, sql in zip(blocks[::2], blocks[1::2]):
    df = pd.read_sql_query(sql.strip().rstrip(";"), con)
    df.to_csv(out/f"{name}.csv", index=False)
    print(f"{name:32s} {len(df):5d} rows")

# full current stock status (all 600 store x SKU rows) for Power BI
pd.read_sql_query("SELECT * FROM vw_stock_status", con).to_csv(out/"stock_status_all.csv", index=False)
con.close()
