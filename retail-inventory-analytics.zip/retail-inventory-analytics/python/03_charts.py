"""Step 3 - static charts + a one-page dashboard preview (PNG) from the SQL outputs."""
import pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
T = ROOT/"outputs/tables"; C = ROOT/"outputs/charts"; C.mkdir(parents=True, exist_ok=True)
rd = lambda n: pd.read_csv(T/f"{n}.csv")

BLUE, ORANGE, RED, GRAY, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#e34948", "#a9a8a2", "#0b0b0b", "#52514e", "#e6e5e0"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": MUTED,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 10.5, "axes.titlecolor": INK, "axes.titlelocation": "left"})
inr = lambda v: f"₹{v/1e7:.2f} Cr" if v >= 1e7 else (f"₹{v/1e5:.1f} L" if v >= 1e5 else f"₹{v:,.0f}")

def style(ax, grid="y"):
    ax.grid(axis=grid, color=GRID, lw=.8); ax.set_axisbelow(True)

def monthly(ax):
    d = rd("monthly_sales_trend"); x = range(len(d))
    ax.plot(x, d.revenue/1e5, color=BLUE, lw=2, marker="o", ms=5, mec="white", mew=1.5)
    ax.set_xticks(list(x)); ax.set_xticklabels([pd.Timestamp(m+"-01").strftime("%b") for m in d.year_month], rotation=0, fontsize=8)
    ax.set_ylabel("Revenue (₹ lakh)"); ax.set_title("Monthly revenue (peak "+inr(d.revenue.max())+")"); style(ax); ax.set_ylim(0, d.revenue.max()/1e5*1.15)

def status(ax):
    d = rd("stock_status_counts").set_index("stock_status").reindex(["Healthy", "Shortage Risk", "Stockout", "Overstock"])
    cols = [GRAY, ORANGE, RED, BLUE]
    b = ax.bar(d.index, d.sku_store_combinations, color=cols, width=.55)
    for r, v in zip(b, d.sku_store_combinations): ax.text(r.get_x()+r.get_width()/2, v+6, f"{v}", ha="center", color=INK, fontsize=9, fontweight="bold")
    ax.set_title("Stock status: SKU × store combinations (600)"); ax.set_ylabel("Combinations"); style(ax); ax.set_ylim(0, d.sku_store_combinations.max()*1.12)

def category(ax):
    d = rd("category_performance").sort_values("inventory_turnover")
    b = ax.barh(d.category, d.inventory_turnover, color=BLUE, height=.6)
    for r, v, dio in zip(b, d.inventory_turnover, d.days_inventory_outstanding): ax.text(v+.5, r.get_y()+r.get_height()/2, f"{v:.1f}×  ({dio:.0f} days)", va="center", color=INK, fontsize=8)
    ax.set_title("Turnover by category (×/yr · days on hand)"); style(ax, "x"); ax.set_xlim(0, d.inventory_turnover.max()*1.3)

def lost(ax):
    d = rd("top_high_demand_at_risk").head(10).iloc[::-1]
    ax.barh(d.sku+" · "+d.category, d.est_lost_revenue/1e5, color=ORANGE, height=.6)
    for i, v in enumerate(d.est_lost_revenue/1e5): ax.text(v+.06, i, f"₹{v:.1f} L", va="center", color=INK, fontsize=8)
    ax.set_title("High-demand SKUs losing sales to stockouts"); ax.set_xlabel("Estimated lost revenue (₹ lakh)"); style(ax, "x"); ax.set_xlim(0, (d.est_lost_revenue/1e5).max()*1.2)

def over(ax):
    d = rd("top_slow_movers_overstocked").head(10).iloc[::-1]
    ax.barh(d.sku+" · "+d.category, d.excess_value/1e3, color=BLUE, height=.6)
    for i, (v, c) in enumerate(zip(d.excess_value/1e3, d.days_of_cover)): ax.text(v+.8, i, f"₹{v:.0f}K · {c:.0f} d cover", va="center", color=INK, fontsize=8)
    ax.set_title("Slow movers tying up cash in excess stock"); ax.set_xlabel("Excess inventory at cost (₹ thousand)"); style(ax, "x"); ax.set_xlim(0, (d.excess_value/1e3).max()*1.45)

def abc(ax):
    d = rd("abc_summary")
    b = ax.bar(d.abc_class, d.revenue_share_pct, color=[BLUE, "#7aaae6", "#bcd3f2"], width=.5)
    for r, v, n in zip(b, d.revenue_share_pct, d.products): ax.text(r.get_x()+r.get_width()/2, v+1.5, f"{v:.0f}% of revenue\n{n} products", ha="center", color=INK, fontsize=8.5)
    ax.set_title("ABC classification"); ax.set_ylabel("Revenue share (%)"); style(ax); ax.set_ylim(0, 100)

panels = {"01_monthly_revenue": monthly, "02_stock_status": status, "03_turnover_by_category": category,
          "04_lost_sales_high_demand": lost, "05_overstock_slow_movers": over, "06_abc_classification": abc}
for name, fn in panels.items():
    fig, ax = plt.subplots(figsize=(7, 4)); fn(ax); fig.tight_layout(); fig.savefig(C/f"{name}.png", dpi=160); plt.close(fig)

# ---- one-page dashboard preview
k = rd("kpi_summary").iloc[0]
fig = plt.figure(figsize=(16, 10), facecolor="white")
gt = GridSpec(1, 6, figure=fig, left=.13, right=.97, top=.89, bottom=.79, wspace=.12)
gs = GridSpec(2, 6, figure=fig, left=.13, right=.97, top=.72, bottom=.06, hspace=.4, wspace=1.0)
fig.text(.04, .955, "Retail Inventory & Sales Analytics", fontsize=19, fontweight="bold", color=INK)
fig.text(.04, .925, "Oct 2025 – Sep 2026 · 5 stores · 120 SKUs · simulated data · layout preview of the Power BI dashboard", fontsize=10, color=MUTED)
tiles = [("Revenue", inr(k.total_revenue)), ("Gross margin", f"{k.gross_margin_pct:.1f}%"), ("Inventory turnover", f"{k.overall_inventory_turnover:.1f}×/yr"),
         ("Days on hand", f"{k.days_inventory_outstanding:.0f} days"), ("Lost sales (stockouts)", inr(k.est_lost_revenue_from_stockouts)), ("Excess stock (at cost)", inr(k.excess_inventory_value))]
for i, (lab, val) in enumerate(tiles):
    ax = fig.add_subplot(gt[0, i]); ax.axis("off")
    ax.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax.transAxes, fc="#f6f5f1", ec=GRID))
    ax.text(.07, .66, lab, transform=ax.transAxes, fontsize=9, color=MUTED); ax.text(.07, .2, val, transform=ax.transAxes, fontsize=17, fontweight="bold", color=INK)
for fn, cell in [(monthly, gs[0, 0:2]), (status, gs[0, 2:4]), (category, gs[0, 4:6]), (lost, gs[1, 0:3]), (over, gs[1, 3:6])]:
    fn(fig.add_subplot(cell))
fig.savefig(C/"00_dashboard_preview.png", dpi=130); plt.close(fig)
print("charts:", sorted(p.name for p in C.iterdir()))
