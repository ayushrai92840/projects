"""Step 5 - Export a clean star schema (CSV) for Power BI Desktop -> powerbi/data/"""
import sqlite3, pandas as pd
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT/"powerbi/data"; OUT.mkdir(parents=True, exist_ok=True)
con = sqlite3.connect(ROOT/"retail.db")
q = lambda s: pd.read_sql_query(s, con)

dates = pd.DataFrame({"date": pd.date_range("2025-10-01", "2026-09-30")})
dates["year"] = dates.date.dt.year; dates["month_no"] = dates.date.dt.month; dates["month_name"] = dates.date.dt.strftime("%b")
dates["year_month"] = dates.date.dt.strftime("%Y-%m"); dates["quarter"] = "Q" + dates.date.dt.quarter.astype(str)
dates["day_name"] = dates.date.dt.day_name(); dates["is_weekend"] = dates.date.dt.dayofweek >= 5
dates.to_csv(OUT/"dim_date.csv", index=False)

q("SELECT p.product_id, p.sku, p.product_name, p.category, s.supplier_name, p.unit_cost, p.unit_price, p.lead_time_days "
  "FROM products p JOIN suppliers s USING(supplier_id)").to_csv(OUT/"dim_product.csv", index=False)
q("SELECT * FROM stores").to_csv(OUT/"dim_store.csv", index=False)
q("SELECT s.sale_id, s.sale_date AS date, s.store_id, s.product_id, s.quantity, s.unit_price, s.discount_pct, "
  "ROUND(v.revenue,2) AS revenue, ROUND(v.cogs,2) AS cogs, ROUND(v.gross_profit,2) AS gross_profit "
  "FROM sales s JOIN vw_sales_enriched v USING(sale_id)").to_csv(OUT/"fact_sales.csv", index=False)
q("SELECT i.snapshot_date, i.store_id, i.product_id, i.units_on_hand, ROUND(i.units_on_hand*p.unit_cost,2) AS inventory_value, "
  "i.units_received, i.units_sold, i.stockout_days, i.lost_units FROM inventory_snapshot i JOIN products p USING(product_id)"
  ).to_csv(OUT/"fact_inventory_snapshot.csv", index=False)
q("SELECT store_id, product_id, units_on_hand, units_on_order, reorder_level, ROUND(avg_daily_units,2) AS avg_daily_units, days_of_cover, "
  "stock_status, suggested_order_qty, excess_units, excess_value FROM vw_stock_status").to_csv(OUT/"fact_stock_status.csv", index=False)
q("SELECT product_id, abc_class, movement_class, recommended_action, inventory_turnover, days_inventory_outstanding, gross_margin_pct "
  "FROM vw_product_performance").to_csv(OUT/"dim_product_class.csv", index=False)
for f in sorted(OUT.glob("*.csv")): print(f"{f.name:32s} {len(pd.read_csv(f)):>8,} rows")
