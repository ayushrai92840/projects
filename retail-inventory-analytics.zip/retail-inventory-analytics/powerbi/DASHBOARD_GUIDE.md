# Building the Power BI dashboard (≈ 45 minutes)

`outputs/charts/00_dashboard_preview.png` shows the target layout. A `.pbix` file can only be created in Power BI Desktop, so this guide + the CSVs in `powerbi/data/` are everything you need.

## 1. Load the data
Home → Get data → Text/CSV → load all 7 files in `powerbi/data/`. In Power Query: confirm `date` / `snapshot_date` are **Date** type, `is_weekend` is True/False, and ID columns are Whole Number. Close & Apply.

## 2. Model (Model view) – star schema, all relationships many-to-one, single direction
| From (many) | To (one) |
|---|---|
| fact_sales[date] | dim_date[date] |
| fact_sales[product_id] | dim_product[product_id] |
| fact_sales[store_id] | dim_store[store_id] |
| fact_inventory_snapshot[snapshot_date] | dim_date[date] |
| fact_inventory_snapshot[product_id] | dim_product[product_id] |
| fact_inventory_snapshot[store_id] | dim_store[store_id] |
| fact_stock_status[product_id] | dim_product[product_id] |
| fact_stock_status[store_id] | dim_store[store_id] |
| dim_product_class[product_id] | dim_product[product_id]  (one-to-one is fine; keep single direction) |

Mark `dim_date` as the date table (Table tools → Mark as date table → `date`). Add the measures from `DAX_measures.md`.

## 3. Page 1 – Executive Overview
- **Cards (top row):** Total Revenue, Gross Margin %, Inventory Turnover, Days Inventory Outstanding, Lost Revenue, Excess Inventory Value.
- **Line chart:** dim_date[year_month] × Total Revenue.
- **Clustered bar:** dim_product[category] × Inventory Turnover (add DIO in tooltip).
- **Donut/bar:** fact_stock_status[stock_status] × count (colour Stockout red, Shortage orange, Overstock blue, Healthy grey).
- **Slicers:** dim_store[store_name], dim_product[category], dim_date[year_month].

## 4. Page 2 – Inventory Turnover & Product Performance
- **Scatter:** X = Inventory Turnover, Y = Gross Margin %, size = Total Revenue, details = dim_product[sku], legend = dim_product_class[movement_class].
- **Matrix:** category → sku with Total Revenue, Inventory Turnover, DIO, Stockout Days, Excess Inventory Value; conditional-format DIO (data bars) and Stockout Days (red scale).
- **Slicers:** movement_class (High-Demand / Moderate / Slow-Moving), abc_class.

## 5. Page 3 – Stock Alerts (action page)
- **Table "Reorder now":** store_name, sku, product_name, units_on_hand, days_of_cover, lead_time_days, suggested_order_qty. Filter: stock_status is Stockout or Shortage Risk. Sort by days_of_cover ascending.
- **Table "Overstock":** store_name, sku, product_name, days_of_cover, excess_units, excess_value. Filter: stock_status = Overstock. Sort by excess_value desc.
- **Cards:** Shortage Combos, Stockout Combos, Overstock Combos, Suggested Order Value, Annual Holding Cost of Excess; **What-if slicer** for Holding Rate.
- **Bar:** dim_store[store_name] × Shortage Combos and × Overstock Combos.

## 6. Finishing
Theme: View → Themes (keep 2–3 colours: blue, orange, grey). Add a text box: "Stock status = snapshot at 30-Sep-2026; data simulated." Take a screenshot of each page for your portfolio / GitHub README, and save as `Retail_Inventory_Dashboard.pbix`.
