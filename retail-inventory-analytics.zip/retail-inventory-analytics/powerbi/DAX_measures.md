# DAX measures

Create a table called `_Measures` (Home → Enter Data, one empty column) and add these measures to it.
Also create a **What-if parameter** (Modeling → New parameter): name `Holding Rate`, range 0–0.5, step 0.01, default 0.20 → this creates `[Holding Rate Value]`.

```DAX
-- ===== SALES =====
Total Revenue    = SUM ( fact_sales[revenue] )
Total COGS       = SUM ( fact_sales[cogs] )
Gross Profit     = [Total Revenue] - [Total COGS]
Gross Margin %   = DIVIDE ( [Gross Profit], [Total Revenue] )
Units Sold       = SUM ( fact_sales[quantity] )
Revenue LY-Month Change % =
    VAR cur  = [Total Revenue]
    VAR prev = CALCULATE ( [Total Revenue], DATEADD ( dim_date[date], -1, MONTH ) )
    RETURN DIVIDE ( cur - prev, prev )

-- ===== INVENTORY EFFICIENCY =====
-- average of the month-end inventory values in the current filter context
Avg Inventory Value =
    AVERAGEX (
        VALUES ( fact_inventory_snapshot[snapshot_date] ),
        CALCULATE ( SUM ( fact_inventory_snapshot[inventory_value] ) )
    )
Inventory Turnover = DIVIDE ( [Total COGS], [Avg Inventory Value] )
Days Inventory Outstanding = DIVIDE ( 365, [Inventory Turnover] )

-- ===== STOCKOUTS / SHORTAGES =====
Stockout Days   = SUM ( fact_inventory_snapshot[stockout_days] )
Lost Units      = SUM ( fact_inventory_snapshot[lost_units] )
Lost Revenue    = SUMX ( fact_inventory_snapshot, fact_inventory_snapshot[lost_units] * RELATED ( dim_product[unit_price] ) )
Lost Revenue % of Sales = DIVIDE ( [Lost Revenue], [Total Revenue] )
Shortage Combos =
    CALCULATE ( COUNTROWS ( fact_stock_status ), fact_stock_status[stock_status] IN { "Stockout", "Shortage Risk" } )
Stockout Combos = CALCULATE ( COUNTROWS ( fact_stock_status ), fact_stock_status[stock_status] = "Stockout" )
Suggested Order Value =
    SUMX ( fact_stock_status, fact_stock_status[suggested_order_qty] * RELATED ( dim_product[unit_cost] ) )

-- ===== OVERSTOCK / SLOW-MOVING =====
Overstock Combos     = CALCULATE ( COUNTROWS ( fact_stock_status ), fact_stock_status[stock_status] = "Overstock" )
Current Inventory Value =
    SUMX ( fact_stock_status, fact_stock_status[units_on_hand] * RELATED ( dim_product[unit_cost] ) )
Excess Inventory Value = SUM ( fact_stock_status[excess_value] )
Excess % of Inventory  = DIVIDE ( [Excess Inventory Value], [Current Inventory Value] )
Annual Holding Cost of Excess = [Excess Inventory Value] * [Holding Rate Value]

-- ===== HEALTH FLAG (for conditional formatting / cards) =====
Stock Health % = DIVIDE ( CALCULATE ( COUNTROWS ( fact_stock_status ), fact_stock_status[stock_status] = "Healthy" ), COUNTROWS ( fact_stock_status ) )
```

Notes
- `fact_stock_status` is a **current snapshot** (as of 30-Sep-2026), so date slicers do not filter it; store / product / category slicers do. Say this in a small text box on the page.
- `abc_class`, `movement_class` and `recommended_action` come pre-computed from SQL (`dim_product_class`). To recompute ABC inside Power BI instead, rank products by `[Total Revenue]` with `RANKX` and compare the running share.
