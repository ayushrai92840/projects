#!/usr/bin/env bash
# Rebuilds everything from scratch (about 15 seconds)
set -e
cd "$(dirname "$0")"
python3 python/01_generate_data.py          # simulated data -> data/raw/*.csv
python3 python/02_build_db_and_run_sql.py   # SQLite + views + reports -> outputs/tables/*.csv
python3 python/03_charts.py                 # PNG charts + dashboard preview
python3 python/04_build_excel.py            # Excel workbook (open in Excel/LibreOffice to calculate formulas)
python3 python/05_powerbi_export.py         # star-schema CSVs -> powerbi/data/
