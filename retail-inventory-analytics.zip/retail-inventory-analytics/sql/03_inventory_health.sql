-- 03_inventory_health.sql : stock-out / shortage and overstock detection

-- Average daily demand per store+SKU over the last 90 days
DROP VIEW IF EXISTS vw_recent_demand;
CREATE VIEW vw_recent_demand AS
SELECT store_id, product_id, SUM(quantity) * 1.0 / 90 AS avg_daily_units
FROM sales
WHERE sale_date > date((SELECT as_of_date FROM vw_as_of), '-90 day')
GROUP BY store_id, product_id;

-- Current stock status per store+SKU
--   days_of_cover  = units on hand / avg daily units (last 90 days)
--   Stockout       : nothing on the shelf
--   Shortage Risk  : stock will run out before a new order could arrive (cover < supplier lead time)
--   Overstock      : more than 90 days of cover
--   Healthy        : everything else
-- Overstock cost: units above 60 days of cover, valued at cost, x 20% annual holding cost (assumption)
DROP VIEW IF EXISTS vw_stock_status;
CREATE VIEW vw_stock_status AS
WITH base AS (
  SELECT c.store_id, st.store_name, c.product_id, p.sku, p.product_name, p.category,
         p.unit_cost, p.unit_price, p.lead_time_days,
         c.units_on_hand, c.reorder_level, c.units_on_order,
         COALESCE(d.avg_daily_units, 0) AS avg_daily_units
  FROM inventory_current c
  JOIN products p  ON p.product_id = c.product_id
  JOIN stores   st ON st.store_id  = c.store_id
  LEFT JOIN vw_recent_demand d ON d.store_id = c.store_id AND d.product_id = c.product_id
), calc AS (
  SELECT *,
         CASE WHEN avg_daily_units > 0 THEN ROUND(units_on_hand / avg_daily_units, 1)
              WHEN units_on_hand > 0   THEN 999.0 ELSE 0 END AS days_of_cover
  FROM base
)
SELECT *,
  CASE WHEN units_on_hand = 0                        THEN 'Stockout'
       WHEN days_of_cover < lead_time_days           THEN 'Shortage Risk'
       WHEN days_of_cover > 90                       THEN 'Overstock'
       ELSE 'Healthy' END AS stock_status,
  -- units to order now to reach (lead time + 30 days) of cover
  CASE WHEN units_on_hand = 0 OR days_of_cover < lead_time_days
       THEN MAX(CAST(ROUND(avg_daily_units * (lead_time_days + 30) - units_on_hand - units_on_order) AS INTEGER), 0)
       ELSE 0 END AS suggested_order_qty,
  CASE WHEN days_of_cover > 90
       THEN MAX(CAST(ROUND(units_on_hand - avg_daily_units * 60) AS INTEGER), 0) ELSE 0 END AS excess_units,
  CASE WHEN days_of_cover > 90
       THEN ROUND(MAX(units_on_hand - avg_daily_units * 60, 0) * unit_cost, 2) ELSE 0 END AS excess_value,
  CASE WHEN days_of_cover > 90
       THEN ROUND(MAX(units_on_hand - avg_daily_units * 60, 0) * unit_cost * 0.20, 2) ELSE 0 END AS annual_holding_cost
FROM calc;
