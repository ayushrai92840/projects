-- 05_reports.sql : business reports. Each block starts with "-- name: <file name>" and is exported to outputs/tables/<name>.csv

-- name: kpi_summary
WITH s AS (SELECT SUM(revenue) rev, SUM(cogs) cogs, SUM(gross_profit) gp, SUM(quantity) units FROM vw_sales_enriched),
     p AS (SELECT SUM(avg_inventory_value) inv_val, SUM(lost_units * unit_price) lost_rev FROM vw_product_base),
     st AS (SELECT COUNT(*) total_pairs,
                   SUM(stock_status IN ('Stockout','Shortage Risk')) short_pairs,
                   SUM(stock_status = 'Stockout') stockout_pairs,
                   SUM(stock_status = 'Overstock') over_pairs,
                   SUM(excess_value) excess_val, SUM(annual_holding_cost) hold_cost,
                   SUM(units_on_hand * unit_cost) cur_inv_val FROM vw_stock_status)
SELECT ROUND(s.rev) AS total_revenue, ROUND(s.gp) AS gross_profit, ROUND(100.0*s.gp/s.rev,1) AS gross_margin_pct,
       s.units AS units_sold,
       ROUND(s.cogs / p.inv_val, 2) AS overall_inventory_turnover,
       ROUND(365.0 * p.inv_val / s.cogs, 1) AS days_inventory_outstanding,
       ROUND(p.lost_rev) AS est_lost_revenue_from_stockouts,
       st.total_pairs AS sku_store_combinations, st.short_pairs AS shortage_or_stockout_combos,
       st.stockout_pairs AS stockout_combos, st.over_pairs AS overstock_combos,
       ROUND(100.0*st.short_pairs/st.total_pairs,1) AS pct_combos_short,
       ROUND(100.0*st.over_pairs/st.total_pairs,1)  AS pct_combos_over,
       ROUND(st.cur_inv_val) AS current_inventory_value, ROUND(st.excess_val) AS excess_inventory_value,
       ROUND(100.0*st.excess_val/st.cur_inv_val,1) AS excess_pct_of_inventory,
       ROUND(st.hold_cost) AS annual_holding_cost_of_excess
FROM s, p, st;

-- name: monthly_sales_trend
SELECT year_month, ROUND(SUM(revenue)) AS revenue, ROUND(SUM(gross_profit)) AS gross_profit,
       ROUND(100.0*SUM(gross_profit)/SUM(revenue),1) AS gross_margin_pct, SUM(quantity) AS units_sold
FROM vw_sales_enriched GROUP BY year_month ORDER BY year_month;

-- name: category_performance
SELECT p.category, ROUND(SUM(p.revenue)) AS revenue, ROUND(SUM(p.gross_profit)) AS gross_profit,
       ROUND(100.0*SUM(p.gross_profit)/SUM(p.revenue),1) AS gross_margin_pct,
       ROUND(SUM(p.cogs)/SUM(p.avg_inventory_value),2) AS inventory_turnover,
       ROUND(365.0*SUM(p.avg_inventory_value)/SUM(p.cogs),1) AS days_inventory_outstanding,
       SUM(p.stockout_days) AS stockout_days, ROUND(SUM(p.est_lost_revenue)) AS est_lost_revenue,
       ROUND(SUM(p.excess_value)) AS excess_inventory_value
FROM vw_product_performance p GROUP BY p.category ORDER BY revenue DESC;

-- name: store_performance
SELECT st.store_name, ROUND(SUM(v.revenue)) AS revenue, ROUND(100.0*SUM(v.gross_profit)/SUM(v.revenue),1) AS gross_margin_pct,
       (SELECT COUNT(*) FROM vw_stock_status x WHERE x.store_id = st.store_id AND x.stock_status IN ('Stockout','Shortage Risk')) AS shortage_skus,
       (SELECT COUNT(*) FROM vw_stock_status x WHERE x.store_id = st.store_id AND x.stock_status = 'Overstock') AS overstock_skus,
       (SELECT ROUND(SUM(excess_value)) FROM vw_stock_status x WHERE x.store_id = st.store_id) AS excess_inventory_value
FROM vw_sales_enriched v JOIN stores st ON st.store_id = v.store_id GROUP BY st.store_id ORDER BY revenue DESC;

-- name: stock_status_counts
SELECT stock_status, COUNT(*) AS sku_store_combinations, ROUND(SUM(units_on_hand*unit_cost)) AS inventory_value
FROM vw_stock_status GROUP BY stock_status ORDER BY sku_store_combinations DESC;

-- name: reorder_list_shortages
SELECT store_name, sku, product_name, category, units_on_hand, units_on_order, ROUND(avg_daily_units,2) AS avg_daily_units,
       days_of_cover, lead_time_days, stock_status, suggested_order_qty,
       ROUND(suggested_order_qty * unit_cost) AS order_value
FROM vw_stock_status
WHERE stock_status IN ('Stockout','Shortage Risk') AND suggested_order_qty > 0
ORDER BY (stock_status = 'Stockout') DESC, avg_daily_units * unit_price DESC;

-- name: overstock_list
SELECT store_name, sku, product_name, category, units_on_hand, ROUND(avg_daily_units,2) AS avg_daily_units,
       days_of_cover, excess_units, excess_value, annual_holding_cost
FROM vw_stock_status WHERE stock_status = 'Overstock' ORDER BY excess_value DESC;

-- name: product_performance
SELECT * FROM vw_product_performance ORDER BY revenue DESC;

-- name: abc_summary
SELECT abc_class, COUNT(*) AS products, ROUND(SUM(revenue)) AS revenue,
       ROUND(100.0*SUM(revenue)/(SELECT SUM(revenue) FROM vw_product_performance),1) AS revenue_share_pct,
       ROUND(SUM(cogs)/SUM(avg_inventory_value),2) AS inventory_turnover
FROM vw_product_performance GROUP BY abc_class ORDER BY abc_class;

-- name: movement_class_summary
SELECT movement_class, COUNT(*) AS products, ROUND(SUM(revenue)) AS revenue, ROUND(AVG(inventory_turnover),2) AS avg_turnover,
       SUM(stockout_days) AS stockout_days, ROUND(SUM(est_lost_revenue)) AS est_lost_revenue,
       ROUND(SUM(excess_value)) AS excess_inventory_value, ROUND(SUM(annual_holding_cost)) AS annual_holding_cost
FROM vw_product_performance GROUP BY movement_class ORDER BY avg_turnover DESC;

-- name: top_high_demand_at_risk
SELECT sku, product_name, category, inventory_turnover, stockout_days, lost_units, est_lost_revenue, stores_short, recommended_action
FROM vw_product_performance WHERE movement_class = 'High-Demand' AND (stores_short > 0 OR stockout_days >= 15)
ORDER BY est_lost_revenue DESC LIMIT 15;

-- name: top_slow_movers_overstocked
SELECT sku, product_name, category, inventory_turnover, days_inventory_outstanding, days_of_cover, excess_value, annual_holding_cost, recommended_action
FROM vw_product_performance WHERE movement_class = 'Slow-Moving' AND stores_over > 0
ORDER BY excess_value DESC LIMIT 15;
