-- 01_schema.sql : tables for the retail inventory & sales database (SQLite)
DROP TABLE IF EXISTS sales; DROP TABLE IF EXISTS inventory_snapshot; DROP TABLE IF EXISTS inventory_current;
DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS stores; DROP TABLE IF EXISTS suppliers;

CREATE TABLE suppliers (supplier_id INTEGER PRIMARY KEY, supplier_name TEXT);
CREATE TABLE stores    (store_id INTEGER PRIMARY KEY, store_name TEXT, city TEXT, region TEXT, size_sqft INTEGER);
CREATE TABLE products  (product_id INTEGER PRIMARY KEY, sku TEXT UNIQUE, product_name TEXT, category TEXT,
                        supplier_id INTEGER REFERENCES suppliers(supplier_id),
                        unit_cost REAL, unit_price REAL, lead_time_days INTEGER);
CREATE TABLE sales     (sale_id INTEGER PRIMARY KEY, sale_date TEXT, store_id INTEGER REFERENCES stores(store_id),
                        product_id INTEGER REFERENCES products(product_id), quantity INTEGER,
                        unit_price REAL, discount_pct REAL);          -- one row = units of a SKU sold in a store on a day
CREATE TABLE inventory_snapshot (snapshot_date TEXT, store_id INTEGER, product_id INTEGER, units_on_hand INTEGER,
                        units_received INTEGER, units_sold INTEGER, stockout_days INTEGER, lost_units INTEGER,
                        PRIMARY KEY (snapshot_date, store_id, product_id));   -- month-end stock position
CREATE TABLE inventory_current (store_id INTEGER, product_id INTEGER, units_on_hand INTEGER, reorder_level INTEGER,
                        reorder_qty INTEGER, units_on_order INTEGER, PRIMARY KEY (store_id, product_id));

CREATE INDEX ix_sales_date    ON sales(sale_date);
CREATE INDEX ix_sales_prod    ON sales(product_id, store_id);
