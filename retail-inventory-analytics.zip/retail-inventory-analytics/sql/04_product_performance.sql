-- 04_product_performance.sql : turnover, ABC, high-demand / slow-moving flags (one row per product)

DROP VIEW IF EXISTS vw_product_base;
CREATE VIEW vw_product_base AS
WITH sales_12m AS (
  SELECT product_id, SUM(quantity) AS units_sold, SUM(revenue) AS revenue, SUM(cogs) AS cogs, SUM(gross_profit) AS gross_profit
  FROM vw_sales_enriched GROUP BY product_id
), inv AS (   -- average inventory value = mean of the 12 month-end stock values (all stores)
  SELECT product_id, AVG(month_value) AS avg_inventory_value, SUM(stockout_days) AS stockout_days, SUM(lost_units) AS lost_units
  FROM (SELECT i.product_id, i.snapshot_date, SUM(i.units_on_hand * p.unit_cost) AS month_value,
               SUM(i.stockout_days) AS stockout_days, SUM(i.lost_units) AS lost_units
        FROM inventory_snapshot i JOIN products p ON p.product_id = i.product_id
        GROUP BY i.product_id, i.snapshot_date)
  GROUP BY product_id
), cover AS (
  SELECT product_id, SUM(units_on_hand) AS units_on_hand, SUM(avg_daily_units) AS avg_daily_units,
         SUM(CASE WHEN stock_status IN ('Stockout','Shortage Risk') THEN 1 ELSE 0 END) AS stores_short,
         SUM(CASE WHEN stock_status = 'Overstock' THEN 1 ELSE 0 END) AS stores_over,
         SUM(excess_value) AS excess_value, SUM(annual_holding_cost) AS annual_holding_cost
  FROM vw_stock_status GROUP BY product_id
)
SELECT p.product_id, p.sku, p.product_name, p.category, p.unit_cost, p.unit_price, p.lead_time_days,
       s.units_sold, ROUND(s.revenue,2) AS revenue, ROUND(s.cogs,2) AS cogs, ROUND(s.gross_profit,2) AS gross_profit,
       ROUND(100.0 * s.gross_profit / s.revenue, 1)                    AS gross_margin_pct,
       ROUND(i.avg_inventory_value, 2)                                 AS avg_inventory_value,
       ROUND(s.cogs / i.avg_inventory_value, 2)                        AS inventory_turnover,   -- times per year
       ROUND(365.0 * i.avg_inventory_value / s.cogs, 1)                AS days_inventory_outstanding,
       i.stockout_days, i.lost_units, ROUND(i.lost_units * p.unit_price, 2) AS est_lost_revenue,
       c.units_on_hand, ROUND(c.avg_daily_units, 2) AS avg_daily_units_all_stores,
       CASE WHEN c.avg_daily_units > 0 THEN ROUND(c.units_on_hand / c.avg_daily_units, 1) END AS days_of_cover,
       c.stores_short, c.stores_over, ROUND(c.excess_value,2) AS excess_value, ROUND(c.annual_holding_cost,2) AS annual_holding_cost
FROM products p
JOIN sales_12m s ON s.product_id = p.product_id
JOIN inv i       ON i.product_id = p.product_id
JOIN cover c     ON c.product_id = p.product_id;

-- ABC (revenue share: A = first 80% cumulative, B = next 15%, C = last 5%) + turnover quartile + action
DROP VIEW IF EXISTS vw_product_performance;
CREATE VIEW vw_product_performance AS
WITH ranked AS (
  SELECT *,
         SUM(revenue) OVER (ORDER BY revenue DESC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) * 1.0
           / SUM(revenue) OVER ()                                         AS cum_revenue_share,
         NTILE(4) OVER (ORDER BY inventory_turnover)                      AS turnover_quartile   -- 4 = fastest
  FROM vw_product_base
), classed AS (
  SELECT *,
         CASE WHEN cum_revenue_share <= 0.80 THEN 'A' WHEN cum_revenue_share <= 0.95 THEN 'B' ELSE 'C' END AS abc_class,
         CASE turnover_quartile WHEN 4 THEN 'High-Demand' WHEN 1 THEN 'Slow-Moving' ELSE 'Moderate' END   AS movement_class
  FROM ranked
)
SELECT *,
  CASE WHEN movement_class = 'High-Demand' AND (stores_short > 0 OR stockout_days >= 15)
            THEN 'Raise reorder point / safety stock'
       WHEN movement_class = 'Slow-Moving' AND stores_over > 0
            THEN 'Cut order qty, markdown or transfer stock'
       WHEN stores_short > 0 THEN 'Reorder now'
       WHEN stores_over  > 0 THEN 'Pause reorders'
       ELSE 'Monitor' END AS recommended_action
FROM classed;
