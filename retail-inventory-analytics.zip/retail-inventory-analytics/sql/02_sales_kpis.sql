-- 02_sales_kpis.sql : base view + sales KPIs

-- Every sales row with revenue, COGS and gross profit worked out once
DROP VIEW IF EXISTS vw_sales_enriched;
CREATE VIEW vw_sales_enriched AS
SELECT s.sale_id, s.sale_date, strftime('%Y-%m', s.sale_date) AS year_month,
       s.store_id, s.product_id, p.category, s.quantity,
       s.quantity * s.unit_price * (1 - s.discount_pct)        AS revenue,
       s.quantity * p.unit_cost                                AS cogs,
       s.quantity * s.unit_price * (1 - s.discount_pct) - s.quantity * p.unit_cost AS gross_profit
FROM sales s JOIN products p ON p.product_id = s.product_id;

-- The "as of" date = last day of data
DROP VIEW IF EXISTS vw_as_of;
CREATE VIEW vw_as_of AS SELECT MAX(sale_date) AS as_of_date FROM sales;
